import './app/my-app';

window.addEventListener('load', () => {
    console.log("loaded...!");
})